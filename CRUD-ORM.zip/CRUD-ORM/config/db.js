

const { Sequelize } = require('sequelize');

const sequelize = new Sequelize('user', 'postgres', 'task', {
    host: 'localhost',
    dialect: 'postgres',
    logging: false,
});





module.exports = sequelize;


