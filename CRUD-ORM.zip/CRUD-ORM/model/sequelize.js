const sequelize = require ('../config/db');
const {  DataTypes } = require('sequelize');


const UserDetails = sequelize.define('user_details', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    Name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    age: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    }
}, {
    timestamps: false // Disable timestamps
});

(async () => {
    try {
        await sequelize.authenticate();
        console.log('Connected to PostgreSQL database successfully.');
        await UserDetails.sync({ force: false });
        console.log('user_details table synced successfully.');
    } catch (error) {
        console.error('Error connecting to the database or syncing user_details:', error);
    }
})();

module.exports = UserDetails;