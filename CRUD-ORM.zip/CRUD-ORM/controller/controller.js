
const Users = require('../model/sequelize')
const bcrypt = require('bcrypt');

const addUser = async (req, res) => {
    try {
        const { id, Name, age, email, password } = req.body;
        const hashedPassword = await bcrypt.hash(password, 10);
        const newStudent = await Users.create({  id, Name, age, email, password:hashedPassword });
        console.log('Record added successfully');
        res.status(201).json({ status: true, message: 'Record added successfully', data: newStudent });
    } catch (error) {
        console.error('Error adding record to database:', error.message);
        res.status(500).json({ status: false, message: 'Failed to add record' });
    }
};

const getData = async (req,res) => {
    try {
        const user = await Users.findAll()
        res.send(user);
    } catch (error) {
        console.error('Error adding record to database:', error.message);
        res.status(500).json({ status: false, message: 'Failed to add record' });
    }
}

const findUserById = async (req, res) => {
    const id = parseInt(req.params.id);
  
    try {
      // Find the user by ID
      const user = await Users.findByPk(id);
  
      if (!user) {
        return res.status(404).send("User not found");
      }
  
      // Send the user data as the response
      res.status(200).json(user);
    } catch (error) {
      console.error('Error finding user:', error);
      res.status(500).send("Error finding user");
    }
  };
  
  
  

const updateUser = async (req, res) => {
    const id = parseInt(req.params.id);
    const { name, email, password, age } = req.body;
  
    try {
      // Find the user by ID
      const user = await Users.findByPk(id);
  
      if (!user) {
        return res.status(404).send("User not found");
      }
  
      // Update the user
      user.name = name;
      user.email = email;
      user.password = password;
      user.age = age;
  
      await user.save();
  
      res.status(200).send("Update successful");
    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).send("Error updating user");
    }
  };
  
  



const deleteUser = async (req,res)=>{
    const id = parseInt(req.params.id);
    try{
        const user = await Users.findByPk(id);
  
      if (!user) {
        return res.status(404).send("User not found");
      }
       await Users.destroy({
            where: {id }, 
        });
        res.send('remove successfully')
    }
    catch(error){
        res.send('unsuccessfully')
    }
}


module.exports = { addUser, getData, findUserById, deleteUser, updateUser };
