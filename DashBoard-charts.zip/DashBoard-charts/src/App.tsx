import React from 'react'

import './App.css'

import 'bootstrap/dist/css/bootstrap.min.css';
import Home from './components/Home';

function App() {


  return (
    <div className='main'>
   <Home/>
    </div>
  )
}

export default App
