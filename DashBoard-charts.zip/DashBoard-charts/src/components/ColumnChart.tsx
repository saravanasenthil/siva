import React from "react";
import ReactApexChart from 'react-apexcharts';
import '../data.json'

interface ColumnChartProps {}

interface ColumnChartState {
  series: {
    name: string;
    data: number[];
  }[];
  options: {
    chart: {
      type: string;
      height: number;
      width: number;
    };
    plotOptions: {
      bar: {
        horizontal: boolean;
        columnWidth: string;
        endingShape: string;
      };
    };
    dataLabels: {
      enabled: boolean;
    };
    stroke: {
      show: boolean;
      width: number;
      colors: string[];
    };
    xaxis: {
      categories: string[];
    };
    yaxis: {
      title: {
        text: string;
      };
    };
    fill: {
      opacity: number;
    };
    tooltip: {
      y: {
        formatter: (val: number) => string;
      };
    };
  };
}



const ColumnChart: React.FC<ColumnChartProps> = () => {
  

  const [chartState] = React.useState<ColumnChartState>({
    series: [
      {
        name: 'Boys',
        data: [60, 55, 47, 30, 61]
      },
      {
        name: 'Girls',
        data: [40, 35, 61, 50, 27]
      }
    ],
    options: {
      chart: {
        type: 'bar',
        height: 350,
        width: 550
      },
      plotOptions: {
        bar: {
          horizontal: false,
          columnWidth: '55%',
          endingShape: 'rounded'
        }
      },
      dataLabels: {
        enabled: false
      },
      stroke: {
        show: true,
        width: 2,
        colors: ['transparent']
      },
      xaxis: {
        categories: ['IT', 'ECE', 'EEE', 'MECH', 'CSE']
      },
      yaxis: {
        title: {
          text: 'strenth'
        }
      },
      fill: {
        opacity: 1
      },
      tooltip: {
        y: {
          formatter: (val) => ` ${val} strenth`
        }
      }
    }
  });

  return (
    <>
    
      <div id="chart" className="columnChart" style={{ justifyContent: 'center', alignItems: 'center', height: '100vh', marginLeft:'50px' }}>
      {/* <h1>College Chart:</h1> */}
        <ReactApexChart
          options={chartState.options}
          series={chartState.series}
          type="bar"
          height={350}
          width={550}
        />
      </div>
      </>
  );
};

export default ColumnChart;
