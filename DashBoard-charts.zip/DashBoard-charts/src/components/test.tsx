import React from 'react';
import data from '../data.json'; // Adjust the path as necessary

interface DepartmentData {
    subject: string[];
    pass: number[];
    fail: number[];
}

interface CollegeData {
    CSE: DepartmentData;
    MECH: DepartmentData;
    EEE: DepartmentData;
    ECE: DepartmentData;
    IT: DepartmentData;
}

const Test: React.FC = () => {
    const collegeData: CollegeData = data;

    const renderDepartment = (department: DepartmentData, departmentName: string) => (
        <div key={departmentName}>
            <h2>{departmentName}</h2>
            {department.subject.map((subject, index) => (
                <div key={index}>
                    <p>Subject: {subject}</p>
                    <p>Pass Rate: {department.pass[index]}</p>
                    <p>Fail Rate: {department.fail[index]}</p>
                </div>
            ))}
        </div>
    );

    return (
        <div>
            {Object.entries(collegeData).map(([departmentName, departmentData]) => 
                renderDepartment(departmentData, departmentName)
            )}
        </div>
    );
};

export default Test;
