import React from 'react'
import data from '../data.json'

interface DepartmentData {
    subject: string[];
    pass: number[];
    fail: number[];
}

interface CollegeData {
    CSE: DepartmentData;
    MECH: DepartmentData;
    EEE: DepartmentData;
    ECE: DepartmentData;
    IT: DepartmentData;
}

function Filter() {


    const handleDeptClick = ()=>{

    }
  return (
    <div>
      
    </div>
  )
}

export default Filter
