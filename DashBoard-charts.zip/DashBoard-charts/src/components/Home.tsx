

import React from 'react';
import { useState } from 'react';
import Sidebar from './slider';
import ColumnChart from './ColumnChart';
import RoundChart from './pieChart';
import '../App.css'
import Dropdown from 'react-bootstrap/Dropdown';

function Home() {
    const [openSidebarToggle, setOpenSidebarToggle] = useState(false)

    const OpenSidebar = () => {
      setOpenSidebarToggle(!openSidebarToggle)
    }
  return (
    <div>
            <h1>ABC College!</h1>
        <div className="dropdown">
         <Dropdown>
      <Dropdown.Toggle variant="success" id="dropdown-basic">
        DEPT base Fliter
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item href="#/action-1">   EEE</Dropdown.Item>
        <Dropdown.Item href="#/action-2">ECE</Dropdown.Item>
        <Dropdown.Item href="#/action-3">IT</Dropdown.Item>
        <Dropdown.Item href="#/action-3">MECH</Dropdown.Item>
        <Dropdown.Item href="#/action-3">CSE</Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
    </div>
      <div className='grid-container'>
     <Sidebar  openSidebarToggle={openSidebarToggle} OpenSidebar={OpenSidebar}/>
     <ColumnChart/>
     <RoundChart/>
     </div>
    </div>
  )
}

export default Home
